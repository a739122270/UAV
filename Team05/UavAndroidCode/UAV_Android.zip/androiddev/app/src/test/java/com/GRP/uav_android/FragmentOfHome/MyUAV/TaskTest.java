package com.GRP.uav_android.FragmentOfHome.MyUAV;

import org.junit.Test;

import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void setInstance() {
    }

    @Test
    public void getInstance() {
    }

    @Test
    public void getTeamName() {
    }

    @Test
    public void getCaptain() {
    }

    @Test
    public void getUav_amount() {
    }

    @Test
    public void getDistance() {
    }

    @Test
    public void getVelocity() {
    }

    @Test
    public void getHeight() {
    }

    @Test
    public void getHeight_restriction() {
    }
}