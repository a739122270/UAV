package com.GRP.uav_android.FragmentOfHome.Team;

import org.junit.Test;

import static org.junit.Assert.*;

public class MemberTest {

    @Test
    public void setInstance() {
    }

    @Test
    public void getInstance() {
    }

    @Test
    public void getName1() {
    }

    @Test
    public void setName1() {
    }

    @Test
    public void getName2() {
    }

    @Test
    public void setName2() {
    }

    @Test
    public void getName3() {
    }

    @Test
    public void setName3() {
    }

    @Test
    public void getName4() {
    }

    @Test
    public void setName4() {
    }

    @Test
    public void getName5() {
    }

    @Test
    public void setName5() {
    }
}