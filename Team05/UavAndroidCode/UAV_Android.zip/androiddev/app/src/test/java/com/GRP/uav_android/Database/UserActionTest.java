package com.GRP.uav_android.Database;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserActionTest {


    @Test
    public void login() {
    }

    @Test
    public void logout() {
    }

    @Test
    public void updateDeviceInfo() {
    }

    @Test
    public void checkTaskPlace() {
    }

    @Test
    public void findUserId() {
    }

    @Test
    public void getPosition() {
    }

    @Test
    public void getTaskInfo() {
    }

    @Test
    public void getTeamInfo() {
    }

    @Test
    public void findMembers() {
    }

    @Test
    public void quitTeam() {
    }

    @Test
    public void getTeamInfo_demo() {
    }

    @Test
    public void cookie() {
    }

    @Test
    public void getDateStr() {
    }

    @Test
    public void getUserInfo() {
    }

    @Test
    public void changeInfo() {
    }
}