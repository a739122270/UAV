package com.GRP.uav_android.ExistTeamPage;

import org.junit.Test;

import static org.junit.Assert.*;

public class TeamTest {

    @Test
    public void setInstance() {
    }

    @Test
    public void getInstance() {
    }

    @Test
    public void getId() {
    }

    @Test
    public void getName() {
    }

    @Test
    public void getOwner() {
    }

    @Test
    public void getCreator() {
    }

    @Test
    public void getUAV_code() {
    }

    @Test
    public void getC_time() {
    }

    @Test
    public void getOwner_id() {
    }
}